/**
 * Copyright (c) 2011 Nokia Corporation.
 */

var hiddenEnemies = new Array();
